/* kernel code needs to have this defined */
#define __KERNEL__

/* needed for versioned kernels (i.e. most kernels in current use) */
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

/* needed to make a module */
#ifdef MODULE
#include <linux/module.h>
#endif

/* here for two reasons, one, this code is GPL (I just haven't bothered to 
 * include the standard warnings) and two, it keeps insmod from complaining */
MODULE_LICENSE("GPL");

/* variables to be filled in at load time by insmod */
static int the_num;
static char *phrase;

/* these macros setup the mechanism for getting parameters from insmod */
MODULE_PARM(the_num, "i");
MODULE_PARM_DESC(the_num, "An important number\n");
MODULE_PARM(phrase, "s");
MODULE_PARM_DESC(phrase, "A phrase describing the important number\n");


/* init_module is called when the module is loaded */
int init_module(void) 
{
	printk("<1>module registered: '%i' and '%s' passed in.\n", the_num, phrase);
	return 0;
}


/* cleanup_module is called when the module is unloaded */
void cleanup_module(void)
{
	printk("<1>module with important #%i unregistered\n", the_num);
}

