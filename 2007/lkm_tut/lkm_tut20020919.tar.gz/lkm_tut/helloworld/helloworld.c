/* kernel code needs to have this defined */
#define __KERNEL__

/* needed for versioned kernels (i.e. most kernels in current use) */
#ifdef MODVERSIONS
#include <linux/modversions.h>
#endif

/* needed to make a module */
#ifdef MODULE
#include <linux/module.h>
#endif

/* here for two reasons, one, this code is GPL (I just haven't bothered to 
 * include the standard warnings) and two, it keeps insmod from complaining */
MODULE_LICENSE("GPL");

/* init_module is called when the module is loaded */
int init_module(void) 
{
	printk("<1>Hello, I'm a module that just got registered\n");
	return 0;
}


/* cleanup_module is called when the module is unloaded */
void cleanup_module(void)
{
	printk("<1>Bye, I'm a module that just got cleaned-up\n");
}

