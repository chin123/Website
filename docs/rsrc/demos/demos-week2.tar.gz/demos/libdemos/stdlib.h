/*
 * $Id: stdlib.h,v 1.2 2000/09/13 08:00:17 konkers Exp $
 *
 * various usefull definitions
 */

#ifndef __lib_stdlib_h__
#define __lib_stdlib_h__

#define NULL 0

typedef int size_t;

#endif
