/*
 * $Id: ints.h,v 1.1 2000/09/13 07:45:36 konkers Exp $
 *
 */

void init_ints( void );
